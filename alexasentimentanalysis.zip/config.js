var config = 
        {
        username: "922e4390-6e26-4b48-90bc-589edced86b5",
        password: "Sp38ijlfjbbg"
        };
        
module.exports = config;
